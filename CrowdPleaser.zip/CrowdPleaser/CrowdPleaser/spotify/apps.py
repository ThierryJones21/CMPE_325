from django.apps import AppConfig


class SpotifyConfig(AppConfig):
    name = 'spotify'
